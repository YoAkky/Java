package com.airline.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.airline.entities.FlightInformation;


@Repository
public class FlightDAOImpl implements IFlightDAO{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<FlightInformation> viewAllFlights() {
		// TODO Auto-generated method stub
		String qry = "SELECT f FROM FlightInformation f";
		TypedQuery<FlightInformation> query = entityManager.createQuery(qry,
				FlightInformation.class);
		return query.getResultList();
	}
	@Override
	public void addFlight(FlightInformation fly) {
		// TODO Auto-generated method stub
		entityManager.persist(fly);
		entityManager.flush();
		//return pro.getProdId();
	}
	@Override
	public FlightInformation searchFlight(int id) {
		// TODO Auto-generated method stub
		FlightInformation emp=new FlightInformation();
		Query queryOne=entityManager.createQuery("FROM FlightInformation");
        List<FlightInformation> allFlight=queryOne.getResultList();	
		
		for (FlightInformation flight : allFlight) {
			if(flight.getFlightno()==id) {
				emp=flight;
				break;
			}
		}
		return emp;
	}

	/*@Override
	public void updateFlightInformation(FlightInformation flight) {
		// TODO Auto-generated method stub
		Query queryThree=entityManager.createQuery("UPDATE FlightInformation SET empName=:ename,empSalary=:esal,empDepartment=:empDep WHERE empId=:eid");
		queryThree.setParameter("ename",flight.get);
		queryThree.setParameter("esal",emp.getEmpSalary());
		queryThree.setParameter("empDep",emp.getEmpDepartment());
		queryThree.setParameter("eid",emp.getEmpId());
		queryThree.executeUpdate();
		
	}*/
	
}
