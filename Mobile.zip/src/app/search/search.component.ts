import { Component, OnInit } from '@angular/core';
import { MobileModel } from '../model/MobileModel';
import { MobileServiceService } from '../service/mobile-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  mobileSearched: MobileModel;
  mobile: MobileModel[];
  constructor(private mobileservice: MobileServiceService,private router:Router) {
    this.mobileSearched = new MobileModel();
  }

  ngOnInit() {
    
  }
  search(mobileId: number) {
    this.mobileSearched = this.mobileservice.searchMobile(mobileId);
    this.router.navigate(['/search']);
 
    return this.mobileSearched;
    
   
  }


}

