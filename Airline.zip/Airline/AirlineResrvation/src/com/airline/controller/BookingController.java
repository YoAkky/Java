package com.airline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.airline.entities.BookingInformation;
import com.airline.service.IBookingService;




@RestController
public class BookingController {
	
	@Autowired
	private IBookingService bookingservice;
	
	@RequestMapping(value = "/bookinginformation", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<BookingInformation> getHomePage(Model model) {

		return bookingservice.viewAllBookings();
	}
	
	@RequestMapping(value ="/bookinginformation/create/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public List<BookingInformation> createBookingInformation(@RequestBody BookingInformation book) {
		
		System.out.println("hiiii");
		System.out.println(book);
		bookingservice.addBooking(book);;
		return bookingservice.viewAllBookings();
	}
	
	@RequestMapping(value = "/bookinginformation/delete/{id}",
			headers="Accept=application/json",method = RequestMethod.DELETE)
	public List<BookingInformation> cancelBooking(@PathVariable("id") int id) {
		System.out.println(id);
		bookingservice.deleteBooking(id);
		return bookingservice.viewAllBookings();
}

}
