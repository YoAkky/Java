export class BookingInformation{
    private bookingId: number;	
	private  email: String;	
	private noOfPassenger: number;	
	private  classType: String;	
	private totalFare: number;
	private seatNo: number;	
	private  creditCard: String;
	private  sourceCity: String;	
	private  destiny: String;
}