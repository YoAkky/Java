import { Component, OnInit } from '@angular/core';
import { MobileModel } from '../model/MobileModel';
import { MobileServiceService } from '../service/mobile-service.service';
import { Router } from '@angular/router';
import { MOBILES } from '../mock-mobile';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
mobile : MobileModel;
mobileList : MobileModel[];
  constructor(private mobileservice:MobileServiceService,private router:Router) {
    this.mobile= new MobileModel();
   }
  //  onSubmit(form){
  //   console.log(MOBILES)
  //  MOBILES.push(form.value)
  //   this.mobileservice.insertMobile(this.mobile);
  //   this.router.navigate(['/show']);

  //  }

  ngOnInit() {
    this.mobileList = this.mobileservice.getList();
  }
  addMobile() {
    this.mobileservice.insertMobile(this.mobile);
    this.router.navigate(['/show']);
}

}

  