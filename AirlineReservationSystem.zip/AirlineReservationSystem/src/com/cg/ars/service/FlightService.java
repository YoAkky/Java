package com.cg.ars.service;

import java.util.ArrayList;

import com.cg.ars.dto.FlightSchedules;
import com.cg.ars.exception.FlightException;


public interface FlightService {

    FlightSchedules getFlightbyNo(int fNo) throws FlightException;
	
	ArrayList<FlightSchedules>getAllFlights() throws FlightException;
	
	public boolean validateAirline(String airline);
	public boolean validateDepCity(String dCity);
	public boolean validateArrCity(String aCity);	
	public boolean validateFirstSeats(int fSeats);
	
}
