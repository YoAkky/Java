package com.cg.ars.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.ars.dao.FlightDao;
import com.cg.ars.dao.FlightDaoImpl;
import com.cg.ars.dto.FlightSchedules;
import com.cg.ars.exception.FlightException;


public class FlightServiceImpl implements FlightService{
	
	FlightDao dao;
	public void setDao(FlightDao dao){
		this.dao = dao;
	}
	
	public FlightServiceImpl()
	{
		dao = new FlightDaoImpl();
	}

	@Override
	public FlightSchedules getFlightbyNo(int fNo) throws FlightException {
		
		return dao.getFlightbyNo(fNo);
	}

	@Override
	public ArrayList<FlightSchedules> getAllFlights() throws FlightException {
		
		return dao.getAllFlights();
	}

	@Override
	public boolean validateAirline(String airline) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,airline))
		{
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean validateDepCity(String dCity) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,dCity))
		{
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean validateArrCity(String aCity) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,aCity))
		{
			return true;
		}
		else
			return false;
	}


	@Override
	public boolean validateFirstSeats(int fSeats) {
		String pattern = "[0-9]{3}";
		String fs = ""+fSeats;
		if(Pattern.matches(pattern,fs))
		{
			return true;
		}
		else 
			return false;
	}

}
