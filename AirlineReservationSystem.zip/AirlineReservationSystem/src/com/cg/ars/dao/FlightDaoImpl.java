package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.ars.dto.FlightSchedules;
import com.cg.ars.exception.FlightException;
import com.cg.ars.util.DBUtil;
import com.cg.logger.MyLogger;

public class FlightDaoImpl implements FlightDao{

	Connection con;
	Logger logger;
	
	public FlightDaoImpl()
	{
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}


	@Override
	public FlightSchedules getFlightbyNo(int fNo) throws FlightException {
		
		
		FlightSchedules flight = null;
		String qry = "select * from FLIGHTINFO where fNo=?"; //**********
		try
		{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, fNo);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				
				int fNo1 = rs.getInt(1);
				String airline = rs.getString(2);
				String dCity = rs.getString(3);
				String aCity = rs.getString(4);
				
				java.sql.Date date = rs.getDate(5);
				java.time.LocalDate dDate = date.toLocalDate();
				
				java.sql.Date date1 = rs.getDate(6);
				java.time.LocalDate aDate = date1.toLocalDate();
			
				int fSeats = rs.getInt(7);
				double fSeatsfare=rs.getDouble(8);
				
				FlightSchedules g =new FlightSchedules(fNo1, airline, dCity,
						aCity, dDate, aDate, fSeats, fSeatsfare);
				
				System.out.println(g);
				
			}
			else
				throw new FlightException("Flight Details Not Found");
			
		}
		catch(SQLException e)
		{
			throw new FlightException(e.getMessage());
		}
		return flight;
	
	}


	@Override
	public ArrayList<FlightSchedules> getAllFlights() throws FlightException {
		
		
		ArrayList<FlightSchedules>list=new ArrayList<FlightSchedules>();
		String qry = "select * from Flightinfo"; //*************
		
		try{
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				
				int fNo = rs.getInt(1);
				String airline = rs.getString(2);
				String dCity = rs.getString(3);
				String aCity = rs.getString(4);
				
				java.sql.Date date = rs.getDate(5);
				java.time.LocalDate dDate = date.toLocalDate();
				
				java.sql.Date date1 = rs.getDate(6);
				java.time.LocalDate aDate = date1.toLocalDate();
				int fSeats = rs.getInt(7);
				double fSeatsfare=rs.getDouble(8);
				
				FlightSchedules flight =new FlightSchedules(fNo, airline, dCity,
						aCity, dDate, aDate, fSeats, fSeatsfare);
				list.add(flight);
			}
			else
				throw new FlightException("Flight Details Not Found");
		}		
			catch(SQLException e)
			{
				throw new FlightException(e.getMessage());
			}
				
		return list;
		
	}
}
