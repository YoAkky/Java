package com.cg.ars.dto;

import java.time.LocalDate;

public class FlightSchedules {
	
	private int fNo;
	private String airline;
	private String dCity;
	private String aCity;
	private LocalDate dDate;
	private LocalDate aDate;
	private int fSeats;
	private double fSeatsfare;
	

	public FlightSchedules(int fNo, String airline, String dCity,
			String aCity, LocalDate dDate, LocalDate aDate,
			int fSeats, double fSeatsfare) {
		super();
		this.fNo = fNo;
		this.airline = airline;
		this.dCity = dCity;
		this.aCity = aCity;
		this.dDate = dDate;
		this.aDate = aDate;
		this.fSeats = fSeats;
		this.fSeatsfare = fSeatsfare;
	}
	
	public int getFlightno() {
		return fNo;
	}
	public void setFlightno(int fNo) {
		this.fNo = fNo;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDep_city() {
		return dCity;
	}
	public void setDep_city(String dCity) {
		this.dCity = dCity;
	}
	public String getArr_city() {
		return aCity;
	}
	public void setArr_city(String aCity) {
		this.aCity = aCity;
	}
	public LocalDate getDep_date() {
		return dDate;
	}
	public void setDep_date(LocalDate dDate) {
		this.dDate = dDate;
	}
	public LocalDate getArr_date() {
		return aDate;
	}
	public void setArr_date(LocalDate aDate) {
		this.aDate = aDate;
	}
	public int getFseats() {
		return fSeats;
	}
	public void setFseats(int fSeats) {
		this.fSeats = fSeats;
	}
	public double getFseatsfare() {
		return fSeatsfare;
	}
	public void setFseatsfare(double fSeatsfare) {
		this.fSeatsfare = fSeatsfare;
	}
	@Override
	public String toString() {
		return "FlightSchedules [fNo=" + fNo + ", airline=" + airline
				+ ", dCity=" + dCity + ", aCity=" + aCity
				+ ", dDate=" + dDate + ", aDate=" + aDate
				+ ", fSeats=" + fSeats + ", fSeatsfare=" + fSeatsfare + "]";
	}
	
}