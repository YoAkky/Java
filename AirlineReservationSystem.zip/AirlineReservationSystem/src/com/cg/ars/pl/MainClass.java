package com.cg.ars.pl;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ars.dto.BookingInfo;
import com.cg.ars.dto.FlightSchedules;
import com.cg.ars.exception.FlightException;
import com.cg.ars.service.BookingService;
import com.cg.ars.service.BookingServiceImpl;
import com.cg.ars.service.FlightService;
import com.cg.ars.service.FlightServiceImpl;


public class MainClass {

	static FlightService service = new FlightServiceImpl();
		
	static BookingService service1 = new BookingServiceImpl();
	
	public static void main(String[] args) throws FlightException {
		
		int choice=0;
		try(Scanner sc = new Scanner(System.in))
		{do{
			System.out.println("Enter Username:");	
			String uname=sc.next();
			System.out.println("Enter password:");
			String pass=sc.next();
			boolean ref = service1.checkLogin(uname, pass);
			if(ref==true){
			do
			{
				System.out.println("Press 1 To Get Your Flight Details");				
				System.out.println("Press 2 Book your Flight");
				System.out.println("Press 3 Search Flight by Id");
				System.out.println("Press 0 Exit");
				System.out.println("Enter your choice::");
				choice = sc.nextInt();
				switch(choice)
				{
				    case 1 : 
				    	try
				    	{
				    	  ArrayList<FlightSchedules>list = service.getAllFlights();
						for(FlightSchedules obj : list)
						{
							System.out.println(obj);
						}
						}
						catch(FlightException e)
						{
							System.out.println(e.getMessage());
						}
						break;
						
				    case 2 : 
						BookingInfo book = acceptBookingDetails(); 
						if(book!=null)
					{	
						try
						{
							int id = service1.addBookingDetails(book);
							System.out.println("seat booked and booking id = "+id);
						}
						catch(FlightException e)
						{
							System.out.println(e.getMessage());
						}
					}
						break;
					
					case 3 : System.out.println("Enter id to search flight::");
					int fNo = sc.nextInt();
					try
					{
						FlightSchedules ref1 = service.getFlightbyNo(fNo);
						System.out.println(ref1);
					}
					catch(FlightException e)
					{
						System.out.println(e.getMessage());
					}
					break;
					
					
					
					case 0 :
						continue;
				}//switch
				System.out.println("do you want to continue 1-yes   0-No");
				choice = sc.nextInt();
			}while(choice!=0);
			}
			else
			{
				System.out.println("Invalid username or Password");
			}
			System.out.println("Press 1 to restart");
			choice = sc.nextInt();
		}while(choice!=0);}
		
	}//try
		

	
	public static BookingInfo acceptBookingDetails()
	{
		BookingInfo book = null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{//
			System.out.println("Enter email::");
			String email = sc.next();
			if(!service1.validateEmail(email))
			{
				continue;
			}
			else
			{//
				while(true)
				{//
					System.out.println("no of passengers::");
					int noPass = sc.nextInt();
					if(!service1.validateNumberPass(noPass))
					{
						continue;
					}
					else
					{//
						while(true)
						{//
							System.out.println("Enter class type::");
							String classType = sc.next();
							if(!service1.validateClass(classType))
							{
								continue;
							}
							else
							{//
								while(true)
								{//
									System.out.println("Enter calculated total fare::");
									int tFare = sc.nextInt();
									if(!service1.validateFare(tFare))
									{
										continue;
									}
									else
									{//
										while(true)
										{//
											System.out.println("Enter seat number::");
											int seatNo = sc.nextInt();
											if(!service1.validateSeat(seatNo))
											{
												continue;
											}
											else
											{//
												while(true)
												{//
													System.out.println("Enter source city ::");
													String sCity = sc.next();
													if(!service1.validateScity(sCity))
													{
														continue;
													}
													else
													{//
														while(true)
														{//
															System.out.println("Enter destination city ::");
															String destCity = sc.next();
															if(!service1.validateDcity(destCity))
															{
																continue;
															}
															else
															{//
																if(destCity!=null)
																{//
																	book = new BookingInfo();
																	book.setEmail(email);
																	book.setNoPass(noPass);
																	book.setClassType(classType);
																	book.setTFare(tFare);
																	book.setSeatNo(seatNo);
																	book.setSCity(sCity);
																	book.setDestCity(destCity);
																	return book;
																}
																break;	
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		
		}
	}
}
						
													
											
					
