package com.airline.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.dao.FlightDAOImpl;
import com.airline.dao.IFlightDAO;
import com.airline.entities.FlightInformation;


@Service
@Transactional
public class FlightServiceImpl implements IFlightService{
	
	@Autowired
	private IFlightDAO dao;
	
	public FlightServiceImpl() {
		dao = new FlightDAOImpl(); 
	}

	@Override
	public List<FlightInformation> viewAllFlights() {
		// TODO Auto-generated method stub
		return dao.viewAllFlights();
	}

	@Override
	public void addFlight(FlightInformation fly) {
		// TODO Auto-generated method stub
		dao.addFlight(fly);
		
	}

	@Override
	public FlightInformation searchFlight(int id) {
		// TODO Auto-generated method stub
		return dao.searchFlight(id);
	}

}
