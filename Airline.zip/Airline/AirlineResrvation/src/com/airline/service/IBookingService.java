package com.airline.service;

import java.util.List;

import com.airline.entities.BookingInformation;

public interface IBookingService {
	
	public void addBooking(BookingInformation book);
	
	public List<BookingInformation> viewAllBookings();
	
	public void deleteBooking(int id);

}
