package com.cg.ars.service;

import com.cg.ars.dto.BookingInfo;
import com.cg.ars.exception.FlightException;



public interface BookingService {
	
	int addBookingDetails(BookingInfo book) throws FlightException;
	public boolean checkLogin(String username, String password) throws FlightException;
	
	boolean validateEmail(String email);
	boolean validateNumberPass(int noPass);
	boolean validateScity(String sCity);
	boolean validateDcity(String destCity);
	boolean validateClass(String classType);
	boolean validateFare(int tFare);
	boolean validateSeat(int seatNo);
	
	
	
	
	

}
