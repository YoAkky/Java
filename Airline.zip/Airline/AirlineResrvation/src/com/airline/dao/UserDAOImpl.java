/*package com.airline.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.airline.entities.Users;
import com.airline.exception.UserException;


@Repository
public class UserDAOImpl implements IUserDAO {
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public Users getUserByRole(Users role) throws UserException {
		// TODO Auto-generated method stub

		Users use=new Users();
		Query queryOne=entitymanager.createQuery("FROM Users");
        List<Users> allUser=queryOne.getResultList();	
		
		for (Users user : allUser) {
			
			if(user.getRole().equals(role)) {
				
				break;
			}
		}
		
		
		return role;
	}

}
*/