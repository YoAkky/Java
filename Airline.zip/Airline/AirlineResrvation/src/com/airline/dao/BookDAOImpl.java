package com.airline.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.airline.entities.BookingInformation;
import com.airline.entities.FlightInformation;

@Repository
public class BookDAOImpl implements IBookDAO{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void addBooking(BookingInformation book) {
		// TODO Auto-generated method stub
		entityManager.persist(book);
		entityManager.flush();
		
	}

	@Override
	public List<BookingInformation> viewAllBookings() {
		// TODO Auto-generated method stub
		String qry = "SELECT b FROM BookingInformation b";
		TypedQuery<BookingInformation> query = entityManager.createQuery(qry,
				BookingInformation.class);
		return query.getResultList();
	}

	@Override
	public void deleteBooking(int id) {
		// TODO Auto-generated method stub
		Query queryTwo=entityManager.
				createQuery("DELETE FROM BookingInformation WHERE bookingId=:bookid");
		queryTwo.setParameter("bookid",id);
		queryTwo.executeUpdate();
	}

}
