package com.cg.ars.service;

import java.util.regex.Pattern;

import com.cg.ars.dao.BookingDao;
import com.cg.ars.dao.BookingDaoImpl;
import com.cg.ars.dao.FlightDao;
import com.cg.ars.dao.FlightDaoImpl;
import com.cg.ars.dto.BookingInfo;
import com.cg.ars.exception.FlightException;

public class BookingServiceImpl implements BookingService {

	BookingDao dao;

	public void setDao(BookingDao dao) {
		this.dao = dao;
	}

	public BookingServiceImpl() {
		dao = new BookingDaoImpl();
	}

	@Override
	public int addBookingDetails(BookingInfo book) throws FlightException {

		return dao.addBookingDetails(book);
	}

	@Override
	public boolean validateEmail(String email) {
		String pattern = "^(.+)@(.+)$";
		if(Pattern.matches(pattern,email))
		{
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean validateNumberPass(int noPass) {
		String pattern = "[0-9]{1,2}";
		String fs = ""+noPass;
		if(Pattern.matches(pattern,fs))
		{
			return true;
		}
		else 
			return false;
	}

	@Override
	public boolean validateScity(String sCity) {
		String pattern = "[A-Z]{1}[a-z]{3,}";
		if(Pattern.matches(pattern,sCity))
		{
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean validateDcity(String destCity) {
		String pattern = "[A-Z]{1}[a-z]{3,}";
		if(Pattern.matches(pattern,destCity))
		{
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean validateClass(String classType) {
		String pattern = "[A-Z]{1}[a-z]{1,}";
		if(Pattern.matches(pattern,classType))
		{
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean validateFare(int tFare) {
		String pattern = "[0-9]{3,}";
		String fs = ""+tFare;
		if(Pattern.matches(pattern,fs))
		{
			return true;
		}
		else 
			return false;
	   
	}

	@Override
	public boolean validateSeat(int seatNo) {
		String pattern = "[0-9]{1,}";
		String fs = ""+seatNo;
		if(Pattern.matches(pattern,fs))
		{
			return true;
		}
		else 
			return false;
	}

	@Override
	public boolean checkLogin(String username, String password)
			throws FlightException {
		// TODO Auto-generated method stub
		return dao.checkLogin(username, password);
	}
}
