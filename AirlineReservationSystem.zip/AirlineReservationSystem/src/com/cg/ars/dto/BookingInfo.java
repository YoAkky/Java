package com.cg.ars.dto;

public class BookingInfo {
	
	private int id;
	private String email;
	private int noPass;
	private String classType;
	private int tFare;
	private int seatNo;
	private String sCity;
	private String destCity;

	public BookingInfo(int id, String email, int noPass, String classType,
			int tFare, int seatNo, String sCity, String destCity) {
		super();
		this.id = id;
		this.email = email;
		this.noPass = noPass;
		this.classType = classType;
		this.tFare = tFare;
		this.seatNo = seatNo;
		this.sCity = sCity;
		this.destCity = destCity;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getNoPass() {
		return noPass;
	}
	public void setNoPass(int noPass) {
		this.noPass = noPass;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
	public int getTFare() {
		return tFare;
	}
	public void setTFare(int tFare) {
		this.tFare = tFare;
	}
	public int getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
	public String getSCity() {
		return sCity;
	}
	public void setSCity(String sCity) {
		this.sCity = sCity;
	}
	public String getDestCity() {
		return destCity;
	}
	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}
	@Override
	public String toString() {
		return "BookingInfo [id=" + id + ", email=" + email + ", noPass="
				+ noPass + ", classType=" + classType + ", tFare="
				+ tFare + ", seatNo=" + seatNo + ", sCity=" + sCity
				+ ", destCity=" + destCity + "]";
	}
	
	public BookingInfo() {}
	
}
