package com.cg.ars.test;


import static org.junit.Assert.assertNotSame;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ars.dao.BookingDaoImpl;
import com.cg.ars.dto.BookingInfo;
import com.cg.ars.exception.FlightException;
import com.cg.ars.service.BookingServiceImpl;


public class BookingDaoTest {

	BookingServiceImpl service;
	BookingDaoImpl dao = new BookingDaoImpl();
	
	@Before
	public void init(){
		
		dao = new BookingDaoImpl();
		service = new BookingServiceImpl();
		service.setDao(dao);
	}    
		
		@Test
		public void testAddBookingDetails() throws FlightException
		{
			BookingInfo book = new BookingInfo();			
			book.setId(1);
			book.setEmail("akkyrox11@gmail.com");
			book.setNoPass(3);
			book.setClassType("A");
			book.setTFare(6000);
			book.setSeatNo(3);
			book.setSCity("Mumbai");
			book.setDestCity("Pune");	
						
			int id = service.addBookingDetails(book);
			assertNotSame(id,0);
		}
		
	@After
	public void destroy() {
		dao = null;
		service = null;
	}

}
