/*package com.airline.dao;

import com.airline.entities.Users;
import com.airline.exception.UserException;

public interface IUserDAO {
	
	Users getUserByRole(Users role)throws UserException; 

}
*/