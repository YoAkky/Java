package com.airline.dao;

import java.util.List;

import com.airline.entities.BookingInformation;


public interface IBookDAO {
	
	public List<BookingInformation> viewAllBookings();
	
	public void addBooking(BookingInformation book);
	
	public void deleteBooking(int id);
	

}
