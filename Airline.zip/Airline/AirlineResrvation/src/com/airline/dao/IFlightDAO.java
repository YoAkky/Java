package com.airline.dao;

import java.util.List;

import com.airline.entities.FlightInformation;

public interface IFlightDAO {
	
	
	public List<FlightInformation> viewAllFlights();
	
	//public void updateFlightInformation(FlightInformation flight);
	
	public void addFlight(FlightInformation fly);
		
	public FlightInformation searchFlight(int id);

}
