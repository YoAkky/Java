package com.airline.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.dao.BookDAOImpl;
import com.airline.dao.IBookDAO;
import com.airline.entities.BookingInformation;

@Service
@Transactional
public class BookingServiceImpl implements IBookingService{
	
	@Autowired
	private IBookDAO dao;
	
	public BookingServiceImpl() {
		dao = new BookDAOImpl(); 
	}

	@Override
	public void addBooking(BookingInformation book) {
		// TODO Auto-generated method stub
		dao.addBooking(book);
		
	}

	@Override
	public List<BookingInformation> viewAllBookings() {
		// TODO Auto-generated method stub
		return dao.viewAllBookings();
	}

	@Override
	public void deleteBooking(int id) {
		// TODO Auto-generated method stub
		dao.deleteBooking(id);
		
	}

}
