import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent }  from './app.component';
import { FlightList }  from './app.flightlist';
import { BookingList }  from './app.bookingList';

import { HomeComponent }  from './HomeComponent';
import { FlightSearchComponent }  from './FlightSearchComponent';
import {HttpModule} from '@angular/http';
import {Routes, RouterModule} from '@angular/router';

const appRoutes: Routes=[
                     { path: '',  redirectTo:'/getdata',pathMatch: 'full'},
                     { path: 'getdata',  component: FlightList},
                     { path: 'postdata',  component: HomeComponent },
                     {path:'search',component:FlightSearchComponent},
                     {path:'postdata1',component:HomeComponent},
                     { path: '',  redirectTo:'/getdata1',pathMatch: 'full'},
                     { path: 'getdata1',  component: BookingList}
                     
                      ];
@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(appRoutes) ],
  declarations: [ AppComponent,FlightList,HomeComponent,FlightSearchComponent,BookingList],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
