
import { Component, OnInit } from '@angular/core';
import { BookingInformation } from "./bookinginformation";
import { BookingInformationService } from "./bookinginformation.service";
import {Router} from '@angular/router'
@Component({
  selector: 'my-app',
  templateUrl:'./homecomponent.html',
      providers:[BookingInformationService]
})
export class HomeComponent {
   
    flights:BookingInformation[];
statusmessage:string;
constructor(private flightservice:BookingInformationService,private router:Router) {}
    
    
    model:any={};

 addData1():void{
    this.flightservice.addBooking(this.model).subscribe((bookingData)=>this.flights=bookingData,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
    //Navigate from HomeComponent to EmployeeList
    this.router.navigate(['/getdata1']);
} 

addData():void{
    this.flightservice.addBooking(this.model).subscribe((bookingData)=>this.flights=bookingData,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
    //Navigate from HomeComponent to EmployeeList
    this.router.navigate(['/getdata']);
} 
    
}
