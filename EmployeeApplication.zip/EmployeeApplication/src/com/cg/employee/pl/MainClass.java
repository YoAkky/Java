package com.cg.employee.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;

public class MainClass {
	
	static EmployeeService service = new EmployeeServiceImpl();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int choice = 0;
		try(Scanner sc = new Scanner (System.in))
		{
			do
			{
				System.out.println("1-Add Employee");
				System.out.println("2-Remove Employee");
				System.out.println("3-Search by Id");
				System.out.println("4-Get all");
				System.out.println("5-Update Emmployee");
				System.out.println("Enter choice::");
				choice = sc.nextInt();
				switch(choice)
				{
					case 1:
						Employee emp= acceptEmployeeDetails();
					if(emp!=null)
					{									
						try
						{	
							int id = service.addEmployee(emp);
							System.out.println("inserted and id = "+id);
						}
						catch(EmployeeException e)
						{
							System.out.println(e.getMessage());
						}
					}
					break;
					
					case 2:
					System.out.println("Enter EmployeeId that to be deleted");
					int a= sc.nextInt();
					Employee deleteId = new Employee();
					try
					{
						deleteId = service.removeEmployee(a);
							System.out.println("employee deleted is: "+deleteId);
					}
					catch(EmployeeException e)
					{
							System.out.println(e.getMessage());
					}
					break;
						
					
					
					case 3:								//to search employee by Id
					System.out.println("Enter EmployeeId");
					int b= sc.nextInt();
					Employee srchId = new Employee();
					try
					{
						srchId = service.getEmployeeById(b);
						System.out.println("employee serched is: "+srchId);
					}
					catch(EmployeeException e)
					{
						System.out.println(e.getMessage());
					}
					break;
						
					
					case 4:
						try
						{
							ArrayList<Employee> no = service.getAllEmployee();
							System.out.println("All employees are"+no);
						}
							catch(EmployeeException e)
							{
								System.out.println(e.getMessage());
							}
							break;
							
					case 5:
						System.out.println("Enter Employee Salary");
						int d = sc.nextInt();
						System.out.println("Enter EMployee id whos updation is needed");
						int z = sc.nextInt();
						Employee upId = new Employee();
						try
						{
							upId = service.updateEmployee(z,d);
							System.out.println("employee serched is: "+upId);
						}
						catch(EmployeeException e)
						{
							System.out.println(e.getMessage());
						}
						break;
						
				}
				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.nextInt();
			}while (choice!=0);
		}

	}
	public static Employee acceptEmployeeDetails()
	{
		Employee emp = new Employee();
		Scanner sc= new Scanner(System.in);
		
		while(true)
		{
			System.out.println("Enter name::");
			String name = sc.next();
			
			if(!service.validateName(name))
			{
				continue;
			}
			else
			{
				while(true)
				{
				System.out.println("Enter Salary::");
				int sal = sc.nextInt();
				if(!service.validateSalary(sal))
				{
					continue;
				}
				else
				{
					System.out.println("Enter birthdate");
					String date = sc.next();
					DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
					LocalDate bdate = LocalDate.parse(date, format);
					if(bdate!= null)
					{
					emp = new Employee();
					emp.setEmpName(name);
					emp.setEmpSal(sal);
					emp.setbDate(bdate);
					break;
				}
					
			}
				
		}
			
	}
		return emp;
		
		}
	}

}
