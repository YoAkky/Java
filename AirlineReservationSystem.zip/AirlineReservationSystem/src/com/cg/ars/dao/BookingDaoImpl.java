package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;




import org.apache.log4j.Logger;

import com.cg.ars.dto.BookingInfo;
import com.cg.ars.dto.Users;
import com.cg.ars.exception.FlightException;
import com.cg.ars.util.DBUtil;
import com.cg.logger.MyLogger;


public class BookingDaoImpl implements BookingDao{

	Connection con;
	Logger logger;
	
	public BookingDaoImpl()
	{
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}
	
	public int getId() throws FlightException
	{
		logger.info("In getId");
		int id = 0;
		String qry = "select bookid_seq.currval from dual"; 
		try{
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id= rs.getInt(1);
				logger.info("Got Booking with id "+id);
				
			}
		}
		catch(SQLException e)
		{
		
			logger.error("error "+e.getMessage());
			throw new FlightException(e.getMessage());
			
		}
		logger.info("Completed getId");
		return id;
	}

	@Override
	public int addBookingDetails(BookingInfo book) throws FlightException {
		
		logger.info("in add booking details");
		logger.info("booking details:: "+book);
		int id=0;
		String qry = "insert into BOOKINGINFO values(bookid_seq.nextval,?,?,?,?,?,?,?)"; 
		
		String email = book.getEmail();
		int passno = book.getNoPass();
		String ctype = book.getClassType();
		int total = book.getTFare();
		int sno = book.getSeatNo();
		String scity = book.getSCity();
		String dcity = book.getDestCity();
		/*LocalDate bDate = stu.getbDate();
		
		java.sql.Date date = java.sql.Date.valueOf(bDate);*/
		
		try{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1, email);
			pstmt.setInt(2, passno);
			pstmt.setString(3, ctype);
			pstmt.setInt(4, total);
			pstmt.setInt(5, sno);
			pstmt.setString(6, scity);
			pstmt.setString(7, dcity);
			/*pstmt.setDate(3,date);*/
			
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				id = getId();
				logger.info("booked successfully and booking id is ::"+id);
				
			}
			else
				throw new FlightException("unable to insert"+book);
			
		}
		catch(SQLException e)
		{
			logger.error("error in insert = "+e.getMessage());
			throw new FlightException(e.getMessage());
		}
		return id;
	}
	
	@Override
	public boolean checkLogin(String username, String password){
		Users user = null;
		String uname="";
		String pass="";
		
		String qry = "SELECT username, password FROM users where username=? and password =?";
		
		try{
			
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery() ;
			
			while (rs.next()){
				uname= rs.getString("username");
				pass= rs.getString("password");
			
			}}
		catch (SQLException e)
		{
			System.out.println(e);
					
		}
		if ((username.equals(uname))&& (password.equals(pass))){
			System.out.println("Username Password Exit");
			return true;
			
		}
		else{
			System.out.println("Please check username and password");
			return false;
		}
		
	
	}

}
