"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var bookinginformation_service_1 = require("./bookinginformation.service");
var BookingList = (function () {
    function BookingList(flyservice) {
        this.flyservice = flyservice;
    }
    BookingList.prototype.ngOnInit = function () {
        var _this = this;
        this.flyservice.viewAllBookings().subscribe(function (bookingData) { return _this.bookings = bookingData; }, function (error) {
            _this.statusmessage = "Problem with service check server";
        });
    };
    BookingList.prototype.delete = function (id) {
        var _this = this;
        this.flyservice.deleteBooking(id).subscribe(function (bookingData) { return _this.bookings = bookingData; }, function (error) {
            _this.statusmessage = "Problem with service check server";
            // console.error(error);
        });
    };
    return BookingList;
}());
BookingList = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.bookinginformationcomponent.html',
        providers: [bookinginformation_service_1.BookingInformationService]
    }),
    __metadata("design:paramtypes", [bookinginformation_service_1.BookingInformationService])
], BookingList);
exports.BookingList = BookingList;
