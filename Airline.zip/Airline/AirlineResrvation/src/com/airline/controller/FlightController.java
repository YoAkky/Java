package com.airline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.airline.entities.FlightInformation;
import com.airline.service.IFlightService;

@RestController
public class FlightController {

	@Autowired
	private IFlightService flightservice;

	/**
	 * Method fetches all flight details supporting HTTP GET method
	 * 
	 * @param MODEL
	 * @return String - List FlightInformation JSON
	 */

	@RequestMapping(value = "/flightinformation", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<FlightInformation> getHomePage(Model model) {

		return flightservice.viewAllFlights();
	}
	
	
	@RequestMapping(value ="/flightinformation/create/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public List<FlightInformation> createFlightInformation(@RequestBody FlightInformation fly) {
		
		System.out.println("hiiii");
		System.out.println(fly);
		flightservice.addFlight(fly);
		return flightservice.viewAllFlights();
	}
	
	@RequestMapping(value ="/flightinformation/search/{id}",headers="Accept=application/json",method = RequestMethod.GET)
	public FlightInformation searchFlight(@PathVariable("id") int id) {
		System.out.println("In search");
		return flightservice.searchFlight(id);
	}
	
	

	/*
	 * @RequestMapping("/index.obj") public String getHomePage(Model model){
	 * model.addAttribute("flightdetailsList",flightservice.viewAllFlights());
	 * 
	 * return "index"; }
	 * 
	 * @RequestMapping(value="/displayFlight.obj") public String
	 * nextPage(@RequestParam String name, Model model) { try{
	 * List<FlightInformation> list = flightservice.viewAllFlights(); if
	 * (list.isEmpty()) { String msg = "There are no flights";
	 * model.addAttribute("msg", msg); return "myError"; }
	 * model.addAttribute("list", list); return "Flight"; }
	 * catch(DataAccessException dataAccessException) {
	 * model.addAttribute("msg","Technical Problem..Please Try Later!!"); return
	 * "myError"; } }
	 */

}
