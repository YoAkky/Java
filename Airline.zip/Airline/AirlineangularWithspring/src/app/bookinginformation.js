"use strict";
var BookingInformation = (function () {
    function BookingInformation() {
    }
    return BookingInformation;
}());
exports.BookingInformation = BookingInformation;
