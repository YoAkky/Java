export class MobileModel {
    public mobileId: number;
    public mobileName: string;
    public mobilePrice: number;
    public mobileBrand: string;

}